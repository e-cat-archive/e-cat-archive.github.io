Monitor tests:
Gradient & Fill

Use wheel to change color

http://e-cat.nm.ru
madsome@gmail.com
