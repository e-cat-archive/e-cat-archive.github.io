Audio spectrum monitor

Advantages:
- full time & frequency resolution

System requirements:
- 1.7 GHz CPU
- Sound card

Setup your input mixer before use

No installation, settings stored in:
HKEY_CURRENT_USER\Software\eCat\Spectrum


http://e-cat.nm.ru
madsome@gmail.com
